Hazards Outside
===============  

Introducing the "Lethal Company: Outdoors Hazards Edition" mod – because why confine chaos and calamity to the comfort of four walls?  
This mod will let you spawn landmines, turrets and even modded hazards outside with spawn rates configurable to your liking.

So, if you've ever thought to yourself, "Gee, I love Lethal Company, but wouldn't it be great if it tried to kill me in the great outdoors?" – well, this mod's got your back.  
Literally. Because there's probably a turret back there too. Happy surviving!


Installation
------------  

- Install BepinEx.
- Place BepInEx/plugins/LCHazardsOutside.dll in your BepInEx/plugins folder.
- That's it! Only the host needs this mod installed! Amazing!